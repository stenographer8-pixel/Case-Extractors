package com.caseextractor.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class ResultsAdapter(private val items: MutableList<String>) :
    RecyclerView.Adapter<ResultsAdapter.RowHolder>() {

    class RowHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvValue: TextView = view.findViewById(R.id.tvValue)
        val btnCopyRow: MaterialButton = view.findViewById(R.id.btnCopyRow)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): RowHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_result, parent, false)
        return RowHolder(v)
    }

    override fun onBindViewHolder(holder: RowHolder, position: Int) {
        val value = items[position]
        holder.tvValue.text = value
        holder.btnCopyRow.setOnClickListener {
            val ctx = holder.itemView.context
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("case_number", value))
        }
    }

    override fun getItemCount(): Int = items.size

    fun update(newItems: List<String>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
