package com.caseextractor.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream

data class Cell(val text: String, val xCenter: Float, val yCenter: Float)
data class Row(val cells: MutableList<Cell> = mutableListOf())

object PdfOcrEngine {

    val HEADER_REGEX = Regex("case|cms|cnno|c\\.?\\s*no|csno|c/no|cause|court|department|status|judge|hearing|^type$|case\\s*type|title|sr\\.?\\s*no", RegexOption.IGNORE_CASE)

    /**
     * Copies the picked PDF into the app's cache folder so PdfRenderer (which needs
     * a real file descriptor, not a content:// stream) can open it.
     */
    fun copyToCache(context: Context, uri: Uri): File {
        val outFile = File(context.cacheDir, "input_${System.currentTimeMillis()}.pdf")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
        }
        return outFile
    }

    /**
     * Renders every page of the PDF to a Bitmap, runs on-device OCR on each page,
     * and returns one Row list per page (rows reconstructed from line bounding boxes).
     * Calls onProgress(pageDone, totalPages) as it works so the UI can show a progress bar.
     */
    fun processPdf(
        context: Context,
        pdfFile: File,
        onProgress: (Int, Int) -> Unit
    ): List<Row> {
        val pfd: ParcelFileDescriptor =
            ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        val allRows = mutableListOf<Row>()
        val pageCount = renderer.pageCount

        try {
            for (i in 0 until pageCount) {
                val page = renderer.openPage(i)

                // 2x render scale keeps small case-number text sharp for OCR
                val scale = 2f
                val bitmap = Bitmap.createBitmap(
                    (page.width * scale).toInt(),
                    (page.height * scale).toInt(),
                    Bitmap.Config.ARGB_8888
                )
                val matrix = Matrix().apply { setScale(scale, scale) }
                page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()

                val image = InputImage.fromBitmap(bitmap, 0)
                // Tasks.await blocks this background thread until ML Kit finishes this page —
                // simple and reliable for a sequential page-by-page pipeline.
                val visionText = Tasks.await(recognizer.process(image))

                val pageRows = reconstructRows(visionText)
                allRows.addAll(pageRows)

                bitmap.recycle()
                onProgress(i + 1, pageCount)
            }
        } finally {
            renderer.close()
            pfd.close()
            recognizer.close()
        }

        return allRows
    }

    /**
     * Groups OCR'd text lines into table rows using their vertical position,
     * then sorts each row's cells left-to-right by horizontal position —
     * this is what lets us treat a scanned table like real columns.
     */
    private fun reconstructRows(visionText: com.google.mlkit.vision.text.Text): List<Row> {
        val lineInfos = mutableListOf<Cell>()
        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                lineInfos.addAll(splitLineIntoColumnCells(line))
            }
        }
        if (lineInfos.isEmpty()) return emptyList()

        // Sort by vertical position, then cluster lines whose y-centers are close
        // together into the same row (handles slight scan skew).
        val sorted = lineInfos.sortedBy { it.yCenter }
        val rows = mutableListOf<Row>()
        var currentRow = Row()
        var lastY = sorted.first().yCenter
        val rowTolerance = 20f // pixels, tuned for 2x-scaled scanned pages

        for (cell in sorted) {
            if (currentRow.cells.isNotEmpty() && Math.abs(cell.yCenter - lastY) > rowTolerance) {
                currentRow.cells.sortBy { it.xCenter }
                rows.add(currentRow)
                currentRow = Row()
            }
            currentRow.cells.add(cell)
            lastY = cell.yCenter
        }
        if (currentRow.cells.isNotEmpty()) {
            currentRow.cells.sortBy { it.xCenter }
            rows.add(currentRow)
        }
        return rows
    }

    /** A scanned table sometimes has its columns close enough together that the OCR
     *  engine reads two different columns as a single "line" (e.g. "324560324 Muhammad
     *  shafique vs Pop etc" — CMS# and Case Title stuck together). We look at the gaps
     *  between individual words inside the line: a gap noticeably wider than normal word
     *  spacing almost always marks a real column boundary, so we split there. */
    private fun splitLineIntoColumnCells(line: com.google.mlkit.vision.text.Text.Line): List<Cell> {
        val elements = line.elements
        val lineBox = line.boundingBox
        if (elements.isEmpty() || lineBox == null) {
            return if (lineBox != null) listOf(Cell(line.text.trim(), lineBox.exactCenterX(), lineBox.exactCenterY())) else emptyList()
        }

        // Typical gap between words in normal running text, used as our baseline.
        val gaps = mutableListOf<Float>()
        for (i in 1 until elements.size) {
            val prevBox = elements[i - 1].boundingBox ?: continue
            val curBox = elements[i].boundingBox ?: continue
            gaps.add((curBox.left - prevBox.right).toFloat())
        }
        val avgGap = if (gaps.isNotEmpty()) gaps.average().toFloat() else 0f
        // A gap is a "column break" if it's clearly bigger than normal word spacing.
        val columnBreakThreshold = maxOf(avgGap * 2.8f, 18f)

        val groups = mutableListOf<MutableList<com.google.mlkit.vision.text.Text.Element>>()
        var current = mutableListOf(elements[0])
        for (i in 1 until elements.size) {
            val prevBox = elements[i - 1].boundingBox
            val curBox = elements[i].boundingBox
            val gap = if (prevBox != null && curBox != null) (curBox.left - prevBox.right).toFloat() else 0f
            if (gap > columnBreakThreshold) {
                groups.add(current)
                current = mutableListOf(elements[i])
            } else {
                current.add(elements[i])
            }
        }
        groups.add(current)

        if (groups.size == 1) {
            // No split needed — whole line is one cell, as before.
            return listOf(Cell(line.text.trim(), lineBox.exactCenterX(), lineBox.exactCenterY()))
        }

        return groups.mapNotNull { group ->
            val boxes = group.mapNotNull { it.boundingBox }
            if (boxes.isEmpty()) return@mapNotNull null
            val left = boxes.minOf { it.left }
            val right = boxes.maxOf { it.right }
            val top = boxes.minOf { it.top }
            val bottom = boxes.maxOf { it.bottom }
            val text = group.joinToString(" ") { it.text }.trim()
            Cell(text, (left + right) / 2f, (top + bottom) / 2f)
        }
    }

    /**
     * Finds the header row/column whose text matches case-number related keywords,
     * then returns every value below it in that column. Falls back to "every line
     * is its own value" if no clear table header is found.
     */
    fun extractCaseColumn(rows: List<Row>): Pair<String, List<String>> {
        var headerRowIdx = -1
        var headerColIdx = -1

        outer@ for (r in rows.indices.take(20)) {
            val row = rows[r]
            for (c in row.cells.indices) {
                if (HEADER_REGEX.containsMatchIn(row.cells[c].text)) {
                    headerRowIdx = r
                    headerColIdx = c
                    break@outer
                }
            }
        }

        val values = mutableListOf<String>()
        if (headerRowIdx == -1) {
            // No header matched — just return every non-empty OCR line.
            for (row in rows) {
                for (cell in row.cells) {
                    if (cell.text.isNotBlank()) values.add(cell.text)
                }
            }
            return "Extracted Data" to values
        }

        val headerText = rows[headerRowIdx].cells[headerColIdx].text
        for (r in headerRowIdx + 1 until rows.size) {
            val row = rows[r]
            if (headerColIdx < row.cells.size) {
                val v = row.cells[headerColIdx].text
                if (v.isNotBlank()) values.add(v)
            }
        }
        return headerText to values
    }

    /** List of all column header candidates — used to populate the column picker so the
     *  user can choose ANY column (case number, name, court, department, etc).
     *
     *  Detection strategy:
     *  1. Look at the first ~15 rows and count how many cells in each row match common
     *     header keywords (case, cms, court, department, judge, status...). The row with
     *     the MOST keyword matches is almost certainly the real header row.
     *  2. If no row has any keyword match at all, fall back to the row with the most
     *     non-blank cells (ignoring blank-padded cells used for column alignment). */
    fun headerCandidates(rows: List<Row>): Pair<Int, List<String>> {
        if (rows.isEmpty()) return -1 to emptyList()

        val searchRange = rows.indices.take(15)

        var bestKeywordRowIdx = -1
        var bestKeywordMatches = 0
        for (r in searchRange) {
            val matches = rows[r].cells.count { HEADER_REGEX.containsMatchIn(it.text) }
            if (matches > bestKeywordMatches) {
                bestKeywordMatches = matches
                bestKeywordRowIdx = r
            }
        }

        if (bestKeywordRowIdx != -1) {
            return bestKeywordRowIdx to rows[bestKeywordRowIdx].cells.map { it.text }
        }

        // Fallback: row with the most actually-filled (non-blank) cells.
        var bestRowIdx = searchRange.first()
        var bestFilledCount = rows[bestRowIdx].cells.count { it.text.isNotBlank() }
        for (r in searchRange) {
            val filledCount = rows[r].cells.count { it.text.isNotBlank() }
            if (filledCount > bestFilledCount) {
                bestFilledCount = filledCount
                bestRowIdx = r
            }
        }
        return bestRowIdx to rows[bestRowIdx].cells.map { it.text }
    }

    fun extractColumnAt(rows: List<Row>, headerRowIdx: Int, colIdx: Int): List<String> {
        val rawValues = mutableListOf<String>()
        val start = if (headerRowIdx >= 0) headerRowIdx + 1 else 0
        for (r in start until rows.size) {
            val row = rows[r]
            if (colIdx < row.cells.size) {
                val v = row.cells[colIdx].text
                if (v.isNotBlank()) rawValues.add(v)
            }
        }
        return cleanupNumericNoise(rawValues)
    }

    /** OCR sometimes inserts a stray dot, space, or letter into otherwise-numeric values
     *  (e.g. "27676.4123" or "27676O4123" instead of "276764123"). If most values in this
     *  column are clearly numeric, strip out anything that isn't a digit so the column
     *  comes out clean. Columns that are genuinely text (names, titles) are left alone. */
    private fun cleanupNumericNoise(values: List<String>): List<String> {
        if (values.isEmpty()) return values
        val digitHeavy = values.count { v ->
            val digits = v.count { it.isDigit() }
            digits >= (v.length * 0.7)
        }
        val isNumericColumn = digitHeavy >= (values.size * 0.7)
        if (!isNumericColumn) return values

        return values.map { v -> v.filter { it.isDigit() } }
    }

    /** Single image (JPG/PNG) — runs OCR directly on it, no PDF rendering needed. */
    fun processImage(context: Context, uri: Uri): List<Row> {
        val bitmap = android.graphics.BitmapFactory.decodeStream(
            context.contentResolver.openInputStream(uri)
        ) ?: return emptyList()

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val image = InputImage.fromBitmap(bitmap, 0)
        val visionText = Tasks.await(recognizer.process(image))
        recognizer.close()
        bitmap.recycle()
        return reconstructRows(visionText)
    }
}
