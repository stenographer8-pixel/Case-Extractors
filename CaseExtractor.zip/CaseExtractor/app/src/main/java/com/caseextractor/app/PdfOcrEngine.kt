package com.caseextractor.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream

data class Cell(val text: String, val xCenter: Float, val yCenter: Float)
data class Row(val cells: MutableList<Cell> = mutableListOf())

object PdfOcrEngine {

    val HEADER_REGEX = Regex("case|cms|cnno|c\\.?\\s*no|csno|c/no|cause", RegexOption.IGNORE_CASE)

    /**
     * Copies the picked PDF into the app's cache folder so PdfRenderer (which needs
     * a real file descriptor, not a content:// stream) can open it.
     */
    fun copyToCache(context: Context, uri: Uri): File {
        val outFile = File(context.cacheDir, "input_${System.currentTimeMillis()}.pdf")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
        }
        return outFile
    }

    /**
     * Renders every page of the PDF to a Bitmap, runs on-device OCR on each page,
     * and returns one Row list per page (rows reconstructed from line bounding boxes).
     * Calls onProgress(pageDone, totalPages) as it works so the UI can show a progress bar.
     */
    fun processPdf(
        context: Context,
        pdfFile: File,
        onProgress: (Int, Int) -> Unit
    ): List<Row> {
        val pfd: ParcelFileDescriptor =
            ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        val allRows = mutableListOf<Row>()
        val pageCount = renderer.pageCount

        try {
            for (i in 0 until pageCount) {
                val page = renderer.openPage(i)

                // 2x render scale keeps small case-number text sharp for OCR
                val scale = 2f
                val bitmap = Bitmap.createBitmap(
                    (page.width * scale).toInt(),
                    (page.height * scale).toInt(),
                    Bitmap.Config.ARGB_8888
                )
                val matrix = Matrix().apply { setScale(scale, scale) }
                page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()

                val image = InputImage.fromBitmap(bitmap, 0)
                // Tasks.await blocks this background thread until ML Kit finishes this page —
                // simple and reliable for a sequential page-by-page pipeline.
                val visionText = Tasks.await(recognizer.process(image))

                val pageRows = reconstructRows(visionText)
                allRows.addAll(pageRows)

                bitmap.recycle()
                onProgress(i + 1, pageCount)
            }
        } finally {
            renderer.close()
            pfd.close()
            recognizer.close()
        }

        return allRows
    }

    /**
     * Groups OCR'd text lines into table rows using their vertical position,
     * then sorts each row's cells left-to-right by horizontal position —
     * this is what lets us treat a scanned table like real columns.
     */
    private fun reconstructRows(visionText: com.google.mlkit.vision.text.Text): List<Row> {
        val lineInfos = mutableListOf<Cell>()
        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                val yCenter = box.exactCenterY()
                val xCenter = box.exactCenterX()
                lineInfos.add(Cell(line.text.trim(), xCenter, yCenter))
            }
        }
        if (lineInfos.isEmpty()) return emptyList()

        // Sort by vertical position, then cluster lines whose y-centers are close
        // together into the same row (handles slight scan skew).
        val sorted = lineInfos.sortedBy { it.yCenter }
        val rows = mutableListOf<Row>()
        var currentRow = Row()
        var lastY = sorted.first().yCenter
        val rowTolerance = 20f // pixels, tuned for 2x-scaled scanned pages

        for (cell in sorted) {
            if (currentRow.cells.isNotEmpty() && Math.abs(cell.yCenter - lastY) > rowTolerance) {
                currentRow.cells.sortBy { it.xCenter }
                rows.add(currentRow)
                currentRow = Row()
            }
            currentRow.cells.add(cell)
            lastY = cell.yCenter
        }
        if (currentRow.cells.isNotEmpty()) {
            currentRow.cells.sortBy { it.xCenter }
            rows.add(currentRow)
        }
        return rows
    }

    /**
     * Finds the header row/column whose text matches case-number related keywords,
     * then returns every value below it in that column. Falls back to "every line
     * is its own value" if no clear table header is found.
     */
    fun extractCaseColumn(rows: List<Row>): Pair<String, List<String>> {
        var headerRowIdx = -1
        var headerColIdx = -1

        outer@ for (r in rows.indices.take(20)) {
            val row = rows[r]
            for (c in row.cells.indices) {
                if (HEADER_REGEX.containsMatchIn(row.cells[c].text)) {
                    headerRowIdx = r
                    headerColIdx = c
                    break@outer
                }
            }
        }

        val values = mutableListOf<String>()
        if (headerRowIdx == -1) {
            // No header matched — just return every non-empty OCR line.
            for (row in rows) {
                for (cell in row.cells) {
                    if (cell.text.isNotBlank()) values.add(cell.text)
                }
            }
            return "Extracted Data" to values
        }

        val headerText = rows[headerRowIdx].cells[headerColIdx].text
        for (r in headerRowIdx + 1 until rows.size) {
            val row = rows[r]
            if (headerColIdx < row.cells.size) {
                val v = row.cells[headerColIdx].text
                if (v.isNotBlank()) values.add(v)
            }
        }
        return headerText to values
    }

    /** List of all column header candidates — picks the row (within the first ~15) that
     *  has the most cells, since a table header row almost always has the most columns
     *  filled in. This lets the user choose ANY column (case number, name, court, etc.)
     *  instead of relying on keyword matching. */
    fun headerCandidates(rows: List<Row>): Pair<Int, List<String>> {
        if (rows.isEmpty()) return -1 to emptyList()

        val searchRange = rows.indices.take(15)
        var bestRowIdx = searchRange.first()
        var bestCellCount = rows[bestRowIdx].cells.size

        for (r in searchRange) {
            val cellCount = rows[r].cells.size
            if (cellCount > bestCellCount) {
                bestCellCount = cellCount
                bestRowIdx = r
            }
        }
        return bestRowIdx to rows[bestRowIdx].cells.map { it.text }
    }

    fun extractColumnAt(rows: List<Row>, headerRowIdx: Int, colIdx: Int): List<String> {
        val values = mutableListOf<String>()
        val start = if (headerRowIdx >= 0) headerRowIdx + 1 else 0
        for (r in start until rows.size) {
            val row = rows[r]
            if (colIdx < row.cells.size) {
                val v = row.cells[colIdx].text
                if (v.isNotBlank()) values.add(v)
            }
        }
        return values
    }

    /** Single image (JPG/PNG) — runs OCR directly on it, no PDF rendering needed. */
    fun processImage(context: Context, uri: Uri): List<Row> {
        val bitmap = android.graphics.BitmapFactory.decodeStream(
            context.contentResolver.openInputStream(uri)
        ) ?: return emptyList()

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val image = InputImage.fromBitmap(bitmap, 0)
        val visionText = Tasks.await(recognizer.process(image))
        recognizer.close()
        bitmap.recycle()
        return reconstructRows(visionText)
    }
}
