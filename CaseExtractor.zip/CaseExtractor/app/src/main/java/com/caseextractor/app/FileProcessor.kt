package com.caseextractor.app

import android.content.Context
import android.net.Uri
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.xwpf.usermodel.XWPFTable

object FileProcessor {

    /** Excel (.xlsx/.xls) — reads real cell values directly, so accuracy is 100%. */
    fun readExcel(context: Context, uri: Uri): List<Row> {
        val rows = mutableListOf<Row>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            val workbook = WorkbookFactory.create(input)
            val sheet = workbook.getSheetAt(0)
            for (sheetRow in sheet) {
                val row = Row()
                var x = 0f
                for (cell in sheetRow) {
                    val text = try {
                        cell.toString().trim()
                    } catch (e: Exception) {
                        ""
                    }
                    if (text.isNotBlank()) {
                        row.cells.add(Cell(text, x, sheetRow.rowNum.toFloat()))
                    }
                    x += 100f
                }
                if (row.cells.isNotEmpty()) rows.add(row)
            }
            workbook.close()
        }
        return rows
    }

    /** Word (.docx) — reads tables if present, otherwise paragraph-by-paragraph (one "cell" per line). */
    fun readWord(context: Context, uri: Uri): List<Row> {
        val rows = mutableListOf<Row>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            val doc = XWPFDocument(input)

            if (doc.tables.isNotEmpty()) {
                for (table: XWPFTable in doc.tables) {
                    for ((rIdx, tableRow) in table.rows.withIndex()) {
                        val row = Row()
                        for ((cIdx, tableCell) in tableRow.tableCells.withIndex()) {
                            val text = tableCell.text.trim()
                            if (text.isNotBlank()) {
                                row.cells.add(Cell(text, cIdx * 100f, rIdx.toFloat()))
                            }
                        }
                        if (row.cells.isNotEmpty()) rows.add(row)
                    }
                }
            } else {
                for ((idx, para) in doc.paragraphs.withIndex()) {
                    val text = para.text.trim()
                    if (text.isNotBlank()) {
                        rows.add(Row(mutableListOf(Cell(text, 0f, idx.toFloat()))))
                    }
                }
            }
            doc.close()
        }
        return rows
    }
}
