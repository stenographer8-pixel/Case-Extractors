package com.caseextractor.app

import android.content.Context
import android.net.Uri
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.xwpf.usermodel.XWPFTable

object FileProcessor {

    /** Excel (.xlsx/.xls) — reads real cell values directly, so accuracy is 100%.
     *  Important: we read EVERY column position (0 .. lastColumn) for every row, even
     *  if a cell is blank, so that column index always lines up with the header row.
     *  Without this, a row with a blank cell in the middle would "shift" all data left
     *  and misalign with the wrong column — which is what caused missing/wrong values. */
    fun readExcel(context: Context, uri: Uri): List<Row> {
        val rows = mutableListOf<Row>()
        val formatter = org.apache.poi.ss.usermodel.DataFormatter()
        context.contentResolver.openInputStream(uri)?.use { input ->
            val workbook = WorkbookFactory.create(input)
            val sheet = workbook.getSheetAt(0)

            // Find the widest row so every row is read with the same number of columns.
            var maxCol = 0
            for (sheetRow in sheet) {
                if (sheetRow.lastCellNum > maxCol) maxCol = sheetRow.lastCellNum.toInt()
            }

            for (sheetRow in sheet) {
                val row = Row()
                for (c in 0 until maxCol) {
                    val cell = sheetRow.getCell(c, org.apache.poi.ss.usermodel.Row.MissingCellPolicy.RETURN_BLANK_AS_NULL)
                    val text = if (cell != null) {
                        try { formatter.formatCellValue(cell).trim() } catch (e: Exception) { "" }
                    } else ""
                    row.cells.add(Cell(text, c * 100f, sheetRow.rowNum.toFloat()))
                }
                if (row.cells.any { it.text.isNotBlank() }) rows.add(row)
            }
            workbook.close()
        }
        return rows
    }

    /** Word (.docx) — reads tables if present, otherwise paragraph-by-paragraph (one "cell" per line). */
    fun readWord(context: Context, uri: Uri): List<Row> {
        val rows = mutableListOf<Row>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            val doc = XWPFDocument(input)

            if (doc.tables.isNotEmpty()) {
                for (table: XWPFTable in doc.tables) {
                    for ((rIdx, tableRow) in table.rows.withIndex()) {
                        val row = Row()
                        for ((cIdx, tableCell) in tableRow.tableCells.withIndex()) {
                            val text = tableCell.text.trim()
                            if (text.isNotBlank()) {
                                row.cells.add(Cell(text, cIdx * 100f, rIdx.toFloat()))
                            }
                        }
                        if (row.cells.isNotEmpty()) rows.add(row)
                    }
                }
            } else {
                for ((idx, para) in doc.paragraphs.withIndex()) {
                    val text = para.text.trim()
                    if (text.isNotBlank()) {
                        rows.add(Row(mutableListOf(Cell(text, 0f, idx.toFloat()))))
                    }
                }
            }
            doc.close()
        }
        return rows
    }
}
