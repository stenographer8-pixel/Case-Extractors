# Case Extractor — Android App (source code)

Yeh ek native Android app ka source code hai jo:
- **PDF** (scanned CamScanner PDFs sahit) — on-device OCR se parhta hai
- **Word (.docx)** — seedha file ka asal text/table padhta hai, OCR nahi (100% accurate, kyunke ye digital text hai)
- **Excel (.xlsx/.xls)** — seedha cells padhta hai (100% accurate)
- **Image (.jpg/.png)** — on-device OCR se parhta hai
- Sab mein case number jaisa column khud dhoondta hai (header keywords: case, cnno, c.no, csno, cause), ya manually column select karne deta hai
- Result list se ek-ek line copy ya "Copy All" se sab copy ho sakta hai
- Internet ki zarurat NAHI (sab kuch phone ke andar offline hota hai)

## Build kaise karein (zaroori — APK seedha nahi diya ja sakta)

1. **Android Studio** install karein (free): https://developer.android.com/studio
2. Yeh poora `CaseExtractor` folder kisi computer par copy karein
3. Android Studio kholen → **Open** → `CaseExtractor` folder select karein
4. Android Studio khud "Gradle Sync" karega — internet chahiye hoga (ek hi baar, dependencies download karne ke liye — Word/Excel support ki wajah se thora zyada download hoga, ~5-10 minute)
5. Sync complete hone ke baad, upar **Run ▶** button dabayen, apna phone USB se connect karein (ya emulator use karein)
6. App phone par install ho jayegi — "Case Extractor" naam se

Pehli baar build karne mein internet chahiye (libraries download karne ke liye), lekin app install hone ke baad **bilkul offline kaam karta hai** — internet ki zarurat nahi.

## Phone par direct install (APK banane ke baad)

Android Studio mein: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
Phir wahi APK file phone par bhej kar install kar lein (Settings mein "Install unknown apps" allow karna padega).

## Accuracy note

- Word/Excel files digital hote hain — inka data 100% accurate aayega (OCR ki zarurat nahi)
- PDF (scanned) aur Image files OCR se guzarte hain — accuracy bohot achi hai (ML Kit Google ka engine hai) lekin scan ki quality (dhundla scan, tira hua page) par thori asar par sakta hai

## Agar koi error aaye

Sabse pehle "Gradle Sync" ka error message dekhen — zyadatar internet ya SDK version ka masla hota hai. Mujhe error ka text bhejen, main fix kar dunga.
